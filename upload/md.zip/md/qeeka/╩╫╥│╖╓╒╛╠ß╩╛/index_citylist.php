<?php
    require_once(dirname(__FILE__).'/mysql.php');
    require_once(dirname(__FILE__).'/config.php');

    $db=new tg_mysql;
    $db->config($config=array('host'=>$GLOBALS['cfg_dbhost'],'user'=>$GLOBALS['cfg_dbuser'] ,'pass'=>$GLOBALS['cfg_dbpwd'] ,'database'=>$GLOBALS['cfg_dbname']));
 	$sql='SELECT * FROM zx_city_manage order by city_domain';
	$city_info=$db->query($sql,'all');
	if($_POST['citydomain']!=''){
		$sql_search="SELECT * FROM `zx_city_manage` WHERE `city_name` LIKE '%".$_POST['citydomain']."%' or city_domain LIKE '%".$_POST['citydomain']."%'";
		$search_info=$db->query($sql_search,'all');
	}

?>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="content-type" content="text; charset=utf-8" />
    <title>装修公司,上海装修公司,装潢公司,装饰公司,装修设计公司,装潢设计公司 - 齐家网</title>
    <meta name="keywords" content="装修公司,装潢公司,装饰公司,装修设计公司,装潢设计公司" />
    <meta name="description" content="上海装修公司,齐家网装修公司页面聚集了国内最专业的装修公司,装潢公司,装饰公司,装修设计公司,装潢设计公司,国内最专业的装修公司,装饰公司都可以在齐家网找到" />
    <link href="http://ued.jia.com/css/common/base.css?v=20120901" rel="stylesheet" />
    <link href="http://ued.jia.com/css/common/header_v2.css?v=20131201" rel="stylesheet" />
    <link href="http://ued.jia.com/css/common/foot.css?v=20130510" rel="stylesheet" />
    <link href="http://ued.jia.com/css/common/common.css?v=20120901" rel="stylesheet" />
    <link href='http://ued.jia.com/css/common/citylist.css' rel='stylesheet' />
    <script src="http://ued.jia.com/js/common/jquery.js?v=20120901"></script>
    <script src="http://ued.jia.com/js/common/comm.js?v=20120901"></script>
    <!--[if IE 6]><script src="http://zhuangxiu.jia.com/application/views/tpl/js/DD_belatedPNG.js" type="text/javascript"></script><![endif]-->
    <script type="text/javascript">
        var TJJ = {};
        TJJ.t1 = (new Date).getTime();
        TJJ.action = function() {};
        TJJ.UserCookieName = "JIA_user_name";
        TJJ.AreaCookieName = "jia_city_id";
    </script>
    <script src="http://g.tg.com.cn/g.js" type="text/javascript" language="javascript"></script>
    <script src="http://tjj.jia.com/tjj.min.js" type="text/javascript" language="javascript"></script>
    <script type="text/javascript" src="https://passport.jia.com/cas/login/status"></script>
</head>
<body>

<?=file_get_contents('http://www.jia.com/head/2014_shanghai_xue_citylist.html')?>
<div class="wrap">
    <div class="city-recommd city-guide">
        <div class="content">
            <span class="city-guess">猜你要去<a href="http://www.jia.com" data-cityid="other" data-attr="19" data-cityname="全国">全国站</a></span>
            <span class="city-advice">
            <em>推荐城市</em>
            <a href="http://beijing.jia.com" data-attr="19" title="北京">北京</a>
            <a href="http://shanghai.jia.com" data-attr="19" title="上海">上海</a>
            <a href="http://hangzhou.jia.com" data-attr="19" title="杭州">杭州</a>
            <a href="http://nanjing.jia.com" data-attr="19" title="南京">南京</a>
            <a href="http://suzhou.jia.com/" data-attr="19" title="苏州" class="last">苏州</a>
            </span>
        </div>
        <div class="shadow"></div>
    </div>
    <div class="city-select">
        <h2>全国城市选择</h2>
        <div class="city-search-bar clearfix">
            <form action="" class="city-select">
     <select  id="province" name='province'>
            <option value="" selected="true">请选择省份</option>
	 <?
		$province_sql = "SELECT * FROM zx_city_manage group by provinces";
		$province_res=$db->query($province_sql,'all');
		if($province_res){
			foreach($province_res as $key=>$value){
	 ?>
         <option value='<?=$value['provinces']?>'><?=$value['provinces']?></option>
	<?}}?>
            </select>
	 <script>
function check_form(){
		if($("#citydomain").val()=='')
		{
			alert("搜索内容不能为空");
			return false;
		}else{
			return true;
		}

 }
</script>
     <select id="citys" name='citys'>
                    <option value="">请选择城市</option>
                </select>
                <a href="javascript:void(0)" class="decocomy-btn btn-subsite">
                    <span class="btn-left"></span>
                    <span class="btn-content">进入分站</span>
                    <span class="btn-right"></span>
                </a>
            </form>
            <span class="other">或者</span>

            <div class="search-box clearfix">
                <input type="text" name="" id="input_citysearch">
                <a class="btn-search decocomy-btn clearfix">
                    <span class="btn-content">搜 索</span>
                    <span class="btn-right"></span>
                </a>
            </div>
        </div>
    </div>
    <ul class="city-list">
        <li class="city-list-item clearfix">
            <span class="letter-index"><a href="http://www.jia.com"  data-attr="19" data-cityname="全国" data-cityid="other" title="全国">全国</a></span>
            <ul class="letter-city clearfix">
			<li class="letter-city-item">
			</li>
		</ul>
        </li>
		 <?
		$sqlz="SELECT * FROM zx_city_manage where city_group='A' order by sort,city_domain";
		$city_info_z=$db->query($sqlz,'all');
		 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">A</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
		</ul>
        </li>
		<?}?>
		 <?
			$sqlz="SELECT * FROM zx_city_manage where city_group='B' order by sort,city_domain";
			$city_info_z=$db->query($sqlz,'all');
		 if($city_info_z){?>
		<li class="city-list-item clearfix">
            <span class="letter-index">B</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
		<?}?>
		 <?
			$sqlz="SELECT * FROM zx_city_manage where city_group='C' order by sort,city_domain";
			$city_info_z=$db->query($sqlz,'all');
		 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">C</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
		<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='D' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">D</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
		<?}?>

			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='E' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">E</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
		<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='F' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">F</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
		<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='G' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">G</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
		<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='H' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">H</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
		<?}?>

			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='I' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">I</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
		<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='J' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">J</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
				<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='K' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">K</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
				<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='L' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">L</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
				<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='M' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">M</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
				<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='N' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">N</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
				<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='O' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">O</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
				<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='P' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">P</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
				<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='Q' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">Q</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
				<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='R' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">R</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
				<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='S' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">S</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
				<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='T' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">T</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
				<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='U' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">U</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
				<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='V' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">V</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
				<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='W' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">W</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
				<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='X' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">X</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
				<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='Y' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">Y</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
			<?}?>
			 <?
				$sqlz="SELECT * FROM zx_city_manage where city_group='Z' order by sort,city_domain";
				$city_info_z=$db->query($sqlz,'all');
			 if($city_info_z){?>
        <li class="city-list-item clearfix">
            <span class="letter-index">Z</span>
            <ul class="letter-city clearfix">
			 <?
				foreach($city_info_z as $kz=>$vz){
				if($vz['hot_sub']=='true'){?>
			<li class="letter-city-item hot">
			<?}else{?>
			<li class="letter-city-item">
			<?}?>
			<a href="http://<?=$vz['city_domain']?>" data-attr="<?=$vz['city_sub_attribute']?>" title="<?=$vz['city_name']?>"><?=$vz['city_name']?></a><span class="separator">|</span></li>
			<?}?>
            </ul>
        </li>
		<?}?>

    </ul>
    <div class="city-footer-link">
        <ul class="clearfix">
            <li><a href="#"><img src="http://ued.qeeka.com/image/common/subsite_designPic.jpg" alt="看装修效果图" width="219" height="51"> </a></li>
            <li><a href="#"><img src="http://ued.qeeka.com/image/common/subsite_selectDecocomy.jpg" alt="选装修公司" width="166" height="51"> </a></li>
            <li><a href="#"><img src="http://ued.qeeka.com/image/common/subsite_tuangou.jpg" alt="去现场团购" width="179" height="51"> </a></li>
            <li><a href="#"><img src="http://ued.qeeka.com/image/common/subsite_mjc.jpg" alt="买建材" width="189" height="51"> </a></li>
        </ul>
    </div>
</div>

<input type="hidden" name="" value="zixun" class="environmentParam">

<script type="text/javascript">

    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-27731845-1']);
    _gaq.push(['_setDomainName', '.jia.com']);
    _gaq.push(['_addOrganic', 'google', 'as_q']);
    _gaq.push(['_addOrganic', 'soso', 'w']);
    _gaq.push(['_addOrganic', 'yodao', 'q']);
    _gaq.push(['_addOrganic', 'sogou', 'query']);
    _gaq.push(['_addOrganic', 'vnet', 'kw']);
    _gaq.push(['_addOrganic', '3721', 'name']);
    _gaq.push(['_addOrganic', 'baidu', 'word']);
    _gaq.push(['_addOrganic', 'baidu', 'w']);
    _gaq.push(['_addOrganic', 'baidu', 'q1']);
    _gaq.push(['_trackPageview']);
    _gaq.push(['_trackPageLoadTime']);

    (function() {
        var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
        ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
    })();
</script>
<script type="text/javascript" src="http://ued.jia.com/js/common/qeeka.jq.autocomplete.min.js"></script>
<script type="text/javascript">
    $(function () {
        /* 设置cookie */
        var setCookie = function (name, value) {//设置cookie
            var exp = new Date("December 31,2020");
            document.cookie = name + "=" + escape(value) + ";domain=.jia.com;path=/;expires=" + exp.toGMTString();
        };
        var getCookie=function getCookie(name){
            var arr,reg=new RegExp("(^| )"+name+"=([^;]*)(;|$)");
            if(arr=document.cookie.match(reg))
                return (arr[2]);
            else{
                return null;
            }
        }
        /*分站搜索*/
        var $input_citysearch = $("#input_citysearch").val("");//分站输入搜索框
        $input_citysearch.autocomplete({//自动提示
            serviceUrl: "http://www.jia.com/citylist/search.php",
            dataType: "jsonp",
            paramName: "search_name",
            params: {"jquery": "?"},
            onSelect: function (item) {
                if (item.data.sub_attribute == 19) {//设置cookie
                    setCookie("jia_city_id", item.data.city_domain.substring(0, item.data.city_domain.indexOf(".jia.com")));
                    setCookie("jia_city_name", encodeURI(item.data.city_name));
                }
                window.location.href = "http://" + item.data.city_domain;//选中时跳转链接
            },
            onSearchStart: function () {
                $input_citysearch.addClass("loading");
            },
            onSearchComplete: function () {
                $input_citysearch.removeClass("loading");
            },
            transformResult: function (response) {//自定义分装数据
                var sugs = response == null ? [] : $.map(response, function (dataItem) {
                    return { value: dataItem.city_name, data: dataItem }
                });
                return {
                    suggestions: sugs
                };
            }
        })
        $(".btn-search").click(function () {//点击搜索按钮时
            var city_keyword = $input_citysearch.val();
            if (!city_keyword.length) {//输入为空时进行提示
                alert("请在列表中搜索选择");
                return;
            }
            /*获取搜索到的后台分站信息*/
            $input_citysearch.addClass("loading");
            $.getJSON("http://www.jia.com/citylist/search.php?callback=?&search_name=" + city_keyword, function (data) {
                $input_citysearch.removeClass("loading");
                if (data == null || !data.length) {//返回null或者是一个空的数组
                    alert("抱歉，该城市暂未收录");
                } else {
                    alert("请在列表中搜索选择")
                }
            })
        })

        /*推荐城市*/
        $.getJSON("http://zhuangxiu.jia.com/new_api/city_ip_area.php?&callback=?", function (data) {
             var city_id=data.city_area;
            if (getCookie("jia_city_id")!= city_id) {//cookie中的分站与建议分站不一致时显示建议
                $(".city-guess a").attr("href", "http://" + city_id + ".jia.com").text(data.city_name + "站").data("attr", data.sub_attribute).data("cityname", data.city_name).data("cityid", city_id);
            }
        })

        /*城市选择，进入分站*/
        var $cities = $("#citys");
        $("#province").change(function () {
            $cities.find("option:not(':first')").remove();//除第一行外全部移除
            var provinceid = $(this).val();
            $.ajax({
                type: "POST",
                url: "http://www.jia.com/citylist/index_third.php",
                dataType: "json",
                data: "id=" + provinceid,
                success: function (data) {
                    var cityList = "";
                    $.each(data, function (i, v) {
                        cityList += "<option value=" + v.city_domain + " data-attr='" + v.sub_attribute + "'>" + v.city_name + "</option>"
                    })
                    $cities.append($(cityList));
                }
            });
        }).find("option:first").attr("selected",true);

        $cities.change(function () {
            var $selected_opt = $(this).find("option:selected");
            $(".decocomy-btn.btn-subsite").attr("href", "http://" + $selected_opt.val()).data("attr", $selected_opt.data("attr")).data("cityname", $selected_opt.text());
        })
        $(".city-list a,.btn-subsite,.city-recommd a").click(function () {
            var attr_subsite = $(this).data("attr") == null ? 19 : $(this).data("attr"),//默认为19
                url = $(this).attr("href"),
                city_id = $(this).data("cityid")==null? url.substring(7, url.indexOf(".jia.com")): $(this).data("cityid"),
                cityName = $(this).data("cityname") == null ? $(this).text() : $(this).data("cityname");
            if (attr_subsite == 19||attr_subsite==1) {
                setCookie("jia_city_id",city_id);
                setCookie("jia_city_name", encodeURI(cityName));
            }
        })
    })
</script>
<?=file_get_contents("http://cms.tg.com.cn/head/footer.html")?>
</body>
</html>
