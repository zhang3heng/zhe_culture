var location_url = document.location.href;
var city_name = '\u4e0a\u6d77';
var skip_set_city = 0;
var suffix = '';
var host_url = '';
var site_domain = '';
host_url = window.location.host;
host_url = host_url.toLowerCase();
site_domain = host_url;

function getLoginUser(user) {
    if (user == '') {
        ini_top_nav_html('');
    } else {
        ini_top_nav_html(user.name);
    }
}

function URLEncode(clearString) {
    var output = '';
    var x = 0;
    clearString = clearString.toString();
    var regex = /(^[a-zA-Z0-9-_.]*)/;
    while (x < clearString.length) {
        var match = regex.exec(clearString.substr(x));
        if (match != null && match.length > 1 && match[1] != '') {
            output += match[1];
            x += match[1].length;
        } else {
            if (clearString.substr(x, 1) == ' ') {
                clearString[x] == ' '
                output += '+';
            }
            else {
                var charCode = clearString.charCodeAt(x);
                var hexVal = charCode.toString(16);
                output += '%' + ( hexVal.length < 2 ? '0' : '' ) + hexVal.toUpperCase();
            }
            x++;
        }
    }
    return output;
}
function ini_top_nav_html(login_user) {
    var city_id = '';
    city_id = jia_header_get_cookie('jia_city_id');
    if (city_id == 'shanghai' || city_id == 'other') {
        var fenzhan = '';
    } else {
        var fenzhan = city_id + '/';
    }
    var tel = '400-660-7700';
    var div_city_id = jQuery('#region-wrap').attr('city_id');
    if (!div_city_id) {
        div_city_id = jQuery('#region_wrap').attr('city_id');
    }
    if (div_city_id) {
        if (div_city_id != 'shanghai') {
            tel = '400-880-2600';
        }
    }

    var app_id = '201';
    if (site_domain == 'zhuangxiu.jia.com') {
        app_id = '200';
    }
    var returl = URLEncode(location_url);
    var top_nav_html = '<p class="top_info">';
    if (!login_user) {
        top_nav_html += '<a href="https://passport.jia.com/cas/login?service=' + returl + '&app_id=' + app_id + '" id="login">登录</a>';
        top_nav_html += '		<a href="https://passport.jia.com/cas/register?app_id=' + app_id + '&service=' + returl + '" id="register">注册</a>';
    } else {
        top_nav_html += '<a href="http://i.jia.com"> 欢迎您， ' + login_user + ' </a>';
        top_nav_html += '<a id="logout" href="https://passport.jia.com/cas/logout?app_id=' + app_id + '&service=' + returl + '"> 退出 </a>';
        top_nav_html += '<input id="url" type="hidden" value="" name="url">';
    }
    top_nav_html += '</p>';

    top_nav_html += '<ul class="entry_menu" style="position:relative;">	';

    if (div_city_id == 'shanghai') {
        top_nav_html += '<a class="qb_ico_nav" tjjj="top.icon.qianbao" href="http://www.qijiapay.com" target="_blank"><img src="http://ued.jia.com/image/qianbao/qianbao_nav.png" width="77" height="26"></a>';
    }

    top_nav_html += '	<li class="myorder">';
    top_nav_html += '		<a href="http://i.jia.com/" class="menu_hd">我的齐家<b></b></a>';
    top_nav_html += '		<div class="menu_bd hide"><a href="http://i.jia.com/order/order_list.htm">我的订单</a></div>';
    top_nav_html += '	</li>';


    top_nav_html += '<li>';
    top_nav_html += '<a class="menu_hd" target="_blank" href="http://bbs.jia.com/' + fenzhan + '">我的论坛<b></b></a>';
    //top_nav_html+='<div class="menu_bd hide">';
    //top_nav_html+='<div class="menu_bd hide"><a href="http://bbs.jia.com/'+fenzhan+'user.php?type=mycreateforum">我的版块</a>';
    //top_nav_html+='<a href="http://bbs.jia.com/'+fenzhan+'user.php?type=my">我的帖子</a>';
    //top_nav_html+='<a href="http://bbs.jia.com/'+fenzhan+'user.php?type=pm">短消息</a>';
    //top_nav_html+='<a href="http://bbs.jia.com/'+fenzhan+'user.php?type=task">论坛任务</a>';
    if (fenzhan == '') {
        //top_nav_html+='<a href="http://bbs.jia.com/shanghai/user.php">个人中心</a>';
    } else {
        //top_nav_html+='<a href="http://bbs.jia.com/'+fenzhan+'user.php">个人中心</a>';
    }
    //top_nav_html+='<a href="http://bbs.jia.com/'+fenzhan+'user.php?type=search">论坛搜索</a>';
    //top_nav_html+='<a href="http://bbs.jia.com/'+fenzhan+'user.php?type=faq">论坛帮助</a>';
    //top_nav_html+='</div>';

    top_nav_html += '	</li>';
    top_nav_html += '	<li class="seller_center">';
    top_nav_html += '		<a href="http://shop.jia.com/shop/company/company_index">商户中心</a>';
    top_nav_html += '		<a tjjj="sjrz.1" href="http://www.jia.com/zhuanti/zhuanti/zhaoshang/jianjie.php" target="_blank">商家入驻</a>';
    top_nav_html += '	</li>';
    top_nav_html += '	<li class="mini_cart">';
    if (window.location.host == 'tgmall.jia.com') {
        top_nav_html += '	<a class="menu_hd" href="http://tgmall.jia.com/beijing/index.php?c=cart/cart&m=viewcart"><s></s>购物车<b></b></a>';
    } else {
        top_nav_html += '	<a class="menu_hd" href="http://mall.jia.com/order/cart/get_cart"><s></s>购物车<b></b><span style="color:#A8000D" class="red">(0)</span></a>';
        top_nav_html += '	<div class="menu_bd hide"><h2 class="cart_hd">最近加入的商品：</h2><span class="show_cart_msg"></span><ul class="cart_bd"></ul>';
        top_nav_html += '<div class="cart_ft">';
        top_nav_html += '<p class="cart_info">购物车里还有<em></em>个商品</p>';
        top_nav_html += '<p class="cart_operate"><a class="cart_lookup" href="http://mall.jia.com/order/cart/get_cart"><span  style="color:#fff">查看我的购物车</span></a></p>';
        top_nav_html += '</div>';
    }
    top_nav_html += '</div>';
    top_nav_html += '	</li>';
    top_nav_html += '	<li class="help_center"><a href="http://www.jia.com/help/" target="_blank">帮助中心</a></li>';
    if (div_city_id == 'shanghai') {
        top_nav_html += '	<li class="help_center"><a href="http://mall.jia.com/brand/services" id="new_guide" tjjj="new_guide" target="_blank">新手指南</a></li>';
    }
    top_nav_html += '	<li class="mall_tel"><strong>' + tel + '</strong></li>';
    top_nav_html += '</ul>';
    jQuery("#top-nav").html(top_nav_html);

    if (window.location.host != 'tgmall.jia.com') {
        jQuery(".myorder,.mini_cart").hover(function () {
            jQuery(this).find(".menu_bd").removeClass("hide").addClass("show");
            load_cart_data();
        }, function () {
            jQuery(this).find(".menu_hd").removeClass("hover");
            jQuery(this).find(".menu_bd").removeClass("show").addClass("hide");
        });

        jQuery(".mini_cart .cart_bd li").hover(function () {
            jQuery(this).toggleClass("item-highlight");
        });
        load_cart_data();
    }
}

function del_cart_item(item_id, obj) {
    var $this = jQuery(obj);
    jQuery.ajax({
        url: 'http://mall.jia.com/order/cart/top_nav_delete_cart?item_id=' + item_id + '&callback=?',
        type: 'GET',
        async: false,
        dataType: 'jsonp',
        jsonp: 'callback',
        success: function (data) {
            jQuery(".menu_hd .red").text("(" + data['count'] + ")");
            var parentNode = $this.parent().parent().parent();
            parentNode.remove();
            jQuery(".show_cart_msg").html("");
            jQuery(".cart_bd li").eq(4).show();
            var count = (data['count'] - 5 > 0) ? (data['count'] - 5) : 0;
            jQuery(".cart_info em").text(count);
            load_cart_data();
        }
    });
}


function ini_cart_data(da) {
    var data = da.list;
    var item_count = da.item_count;
    if (item_count.shop_msg == 0) {
        jQuery(".menu_hd .red").text("");
        jQuery(".show_cart_msg").html("&nbsp;&nbsp;您的购物车暂时为空，请赶快购物吧！");
        jQuery(".menu_bd ul").html("");
        jQuery(".cart_info em").text('0');
        jQuery(".mini_cart s").removeClass('has');
        jQuery(".menu_hd .red").text("(0)");
    } else {
        var str = '';
        var p_show = 0;
        for (var i = 0; i < data.length; i++) {
            str += '<li class="list' + data[i].itemId + '" ';
            if (i > 4) {
                str += 'style="display: none;"';
            }
            str += '><div class="mc_cart_img"><a href="http://mall.jia.com/item/' + data[i].itemId + '" target="_blank">';
            str += '<img src="http://imgmall.tg.com.cn/' + data[i].imagePath + '" width="40" height="40" ></a></div>';
            str += '<div class="mc_goods_info"><a class="mc_goods_name" href="http://mall.jia.com/item/' + data[i].itemId + '" target="_blank">' + data[i].name + ' *' + data[i].product_count + '</a> </div>';
            str += '<div class="mc_right"> <p class="mc_cart_price">';
            if (data[i].comments || data[i].comments == 'undefined') {
                str += '<span> 颜色:' + data[i].comments + '</span>';
            }
            str += '<span>' + (data[i].price * data[i].product_count).toFixed(2) + '</span> 元</p>     <p class="mc_cart_del"><a href="javascript:void(0)" class="del_item_by_cart" onclick="del_cart_item(' + data[i].itemId + ',this)">删除</a></p>   </div></li>';
            if (i < 5) {
                p_show = parseInt(p_show) + parseInt(data[i].product_count);
            }
        }
        jQuery(".show_cart_msg").html("");
        jQuery(".menu_bd ul").html("");
        jQuery(".menu_hd .red").text("(" + item_count['product_show_count'] + ')');
        jQuery(".cart_bd ").append(str);
        jQuery(".mini_cart s").addClass('has');
        if (parseFloat(da['item_count']['product_show_key']) < 5) {
            jQuery(".cart_info em").text(0);
            jQuery(".cart_info").hide();
        } else {
            jQuery(".cart_info em").text((parseInt(item_count['product_show_count']) - p_show));
        }
    }
}


function load_cart_data() {
    jQuery.ajax({
        type: "get",
        url: "http://mall.jia.com/order/cart/top_nav_js?json=true&callback=?",
        dataType: "jsonp",
        jsonp: 'callback',
        cache: false,
        timeout: 10000,
        error: function (error) {
        },
        success: function (da) {
            jQuery(".cart_bd ").html("");
            ini_cart_data(da);
        }
    });
}

jQuery("head").append("<script src='https://passport.jia.com/cas/login/user'?r=" + Math.random() + "\'></script>");

var huizhou_url = 'http://mall.jia.com';
var huzhou_url = 'http://mall.jia.com';

if (host_url == 'mall.jia.com' || host_url == 'tgmall.jia.com') {
    city_name = '上海';
    skip_set_city = 1;
    host_url = 'http://tgmall.jia.com/';
} else if (host_url == 'jiaju.jia.com' || host_url == 'tgjiaju.jia.com') {
    host_url = 'http://tgjiaju.jia.com/';
} else if (host_url == 'zhuangxiu.jia.com') {
    host_url = 'http://zhuangxiu.jia.com/';
} else if (host_url == 'pinpai.jia.com') {
    host_url = 'http://pinpai.jia.com/';
} else if (host_url == 'bbs.jia.com') {
    host_url = 'http://bbs.jia.com/';
} else if (host_url == 'tg.jia.com') {
    host_url = 'http://tg.jia.com/';
} else {
    if (host_url == 'www.jia.com' || host_url == 'shanghai.jia.com' || host_url == 'zixun.jia.com' || host_url == 'tuku.jia.com') {
        city_name = '上海';
        skip_set_city = 1;
    }
    host_url = 'http://';
    suffix = '.jia.com'
}

var jiaheaderjson = {"region_content": "<span class=\"region-label\">\n\t<span class=\"region-label-name\">\n\t<em id=\"J_region\">" + city_name + "<\/em><i class=\"arrow\">&#12288;<\/i>\n\t<\/span>\n<\/span>\n<div class=\"region-list\">\n\t<dl>\n\t\t<dt>[A-C]<\/dt>\n\t\t<dd><a href=\"" + host_url + "beijing" + suffix + "\">\u5317\u4eac<\/a>\n\t\t<a href=\"" + host_url + "changsha" + suffix + "\">\u957f\u6c99<\/a>\n\t\t<a href=\"" + host_url + "chengdu" + suffix + "\">\u6210\u90fd<\/a>\n\t\t<a href=\"" + host_url + "chongqing" + suffix + "\">\u91cd\u5e86<\/a>\n\t\t<a href=\"" + host_url + "changzhou" + suffix + "\">\u5e38\u5dde<\/a><\/dd>\n\t<\/dl>\n\t<dl>\n\t\t<dt>[D-H]<\/dt>\n\t\t<dd>\n\t\t<a href=\"" + host_url + "hangzhou" + suffix + "\">\u676d\u5dde<\/a>\n\t\t<a href=\"" + host_url + "dalian" + suffix + "\">\u5927\u8fde<\/a>\n\t\t<a href=\"" + host_url + "guangzhou" + suffix + "\">\u5e7f\u5dde<\/a>\n\t\t<a href=\"" + host_url + "haerbin" + suffix + "\">\u54c8\u5c14\u6ee8<\/a>\n\t\t<a href=\"" + huizhou_url + "\">\u60e0\u5dde<\/a>\n\t\t<a href=\"" + huzhou_url + "\">\u6e56\u5dde<\/a>\n\t\t<a href=\"" + host_url + "hefei" + suffix + "\">\u5408\u80a5<\/a>\n\t\t<a href=\"" + host_url + "fuzhou" + suffix + "\">\u798f\u5dde<\/a>\n\t\t<\/dd>\n\t\t<\/dl>\n\t<dl>\n\t\t<dt>[J-Q]<\/dt>\n\t\t<dd><a href=\"" + host_url + "nanjing" + suffix + "\">\u5357\u4eac<\/a>\n\t\t<a href=\"" + host_url + "jinan" + suffix + "\">\u6d4e\u5357<\/a>\n\t\t<a href=\"" + host_url + "qingdao" + suffix + "\">\u9752\u5c9b<\/a>\n\t\t<a href=\"" + host_url + "kunming" + suffix + "\">\u6606\u660e<\/a>\n\t\t<a href=\"" + host_url + "ningbo" + suffix + "\">\u5b81\u6ce2<\/a>\n\t\t<a href=\"" + host_url + "kunshan" + suffix + "\">\u6606\u5c71<\/a>\n\t\t<a href=\"" + host_url + "nantong" + suffix + "\">\u5357\u901a<\/a>\n\t\t<a href=\"" + host_url + "nanning" + suffix + "\">\u5357\u5b81<\/a>\n\t\t<a href=\"" + host_url + "jinhua" + suffix + "\">\u91d1\u534e<\/a>\n\t\t<a href=\"" + host_url + "nanchang" + suffix + "\">\u5357\u660c<\/a><\/dd>\n\t\t<\/dl>\n\t<dl>\n\t\t<dt>[S-Z]<\/dt>\n\t\t<dd><a href=\"" + host_url + "shanghai" + suffix + "\">\u4e0a\u6d77<\/a>\n\t\t<a href=\"" + host_url + "suzhou" + suffix + "\">\u82cf\u5dde<\/a>\n\t\t<a href=\"" + host_url + "wuxi" + suffix + "\">\u65e0\u9521<\/a>\n\t\t<a href=\"" + host_url + "wuhan" + suffix + "\">\u6b66\u6c49<\/a>\n\t\t<a href=\"" + host_url + "tianjin" + suffix + "\">\u5929\u6d25<\/a>\n\t\t<a href=\"" + host_url + "shenyang" + suffix + "\">\u6c88\u9633<\/a>\n\t\t<a href=\"" + host_url + "shenzhen" + suffix + "\">\u6df1\u5733<\/a>\n\t\t<a href=\"" + host_url + "xian" + suffix + "\">\u897f\u5b89<\/a>\n\t\t<a href=\"" + host_url + "yangzhou" + suffix + "\">\u626c\u5dde<\/a>\n\t\t<a href=\"" + host_url + "shijiazhuang" + suffix + "\">\u77f3\u5bb6\u5e84<\/a><\/dd>\n\t<\/dl>\n<\/div>"};

function jia_header_change_city(cname, ccityname) {
    if (cname == 'huizhou' || cname == 'huzhou') {
        cname = 'shanghai';
        ccityname = '上海';
    }
    var expCook = new Date("December 31,2020");
    document.cookie = ("city_id=" + cname + ";path=/; domain=.jia.com;expires=" + expCook.toGMTString());
    document.cookie = ("city_name=" + encodeURI(ccityname) + ";path=/; domain=.jia.com;expires=" + expCook.toGMTString());
    if (location_url.indexOf('bbs.jia.com') > 0) {
        window.location.href = "http://mall.jia.com/bbs.php";
    } else {
        if (cname == 'shanghai') {
            window.location.href = "http://mall.jia.com/"
        } else {
            window.location.href = "http://tgmall.jia.com/" + cname
        }
        //location.reload();
    }
}
/*获取cookie*/
function jia_header_get_cookie(c_name) {
    if (document.cookie.length > 0) {
        c_start = document.cookie.indexOf(c_name + "=");
        if (c_start != -1) {
            c_start = c_start + c_name.length + 1;
            c_end = document.cookie.indexOf(";", c_start);
            if (c_end == -1) c_end = document.cookie.length;
            return unescape(document.cookie.substring(c_start, c_end));
        }
    }
    return "";
}
/*
 *设置当前城市
 * 从cookie取出
 * */
function set_current_city() {
    var div_city_name = jQuery('#region-wrap').attr('city_name');
    if (div_city_name) {
        jQuery('#J_region').html(div_city_name);
        return;
    }
    var c_name = 'city_name';
    var city = '';
    if (document.cookie.length > 0) {
        c_start = document.cookie.indexOf(c_name + "=");
        if (c_start != -1) {
            c_start = c_start + c_name.length + 1;
            c_end = document.cookie.indexOf(";", c_start);
            if (c_end == -1) c_end = document.cookie.length;
            city = decodeURIComponent(document.cookie.substring(c_start, c_end));
        }
    }
    if (city != '') {
        jQuery('#J_region').html(city);
    }
}

jQuery(document).ready(function () {
});