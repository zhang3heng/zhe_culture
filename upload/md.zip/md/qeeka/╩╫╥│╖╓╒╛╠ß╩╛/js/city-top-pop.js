document.write('<link href="http://ued.jia.com/css/common/city-pop.css" rel="stylesheet"><div class="city-guide"><div class="container"><div class="wrapper"><span class="city-guess">猜你要去<a href="http://www.jia.com" tjjj="city.guess.1">全国站</a></span>             <span class="city-advice">             <em>推荐城市</em>             <a href="http://beijing.jia.com" tjjj="city.guess.2" title="北京">北京</a>             <a href="http://shanghai.jia.com" tjjj="city.guess.3" title="上海">上海</a>             <a href="http://hangzhou.jia.com" tjjj="city.guess.4" title="杭州">杭州</a>             <a href="http://nanjing.jia.com" tjjj="city.guess.5" title="南京">南京</a>             <a href="http://suzhou.jia.com" tjjj="city.guess.7" title="苏州" class="last">苏州</a>             </span>             <a href="http://www.jia.com/citylist" tjjj="city.guess.more" class="viewmore">查看更多</a><a href="javascript:void(0)" class="btn-close" title="关闭"></a></div><div class="shadow"></div></div> </div>');
var setCookie = function (name, value) {//设置cookie
    var exp = new Date("December 31,2020");
    document.cookie = name + "=" + encodeURI(value) + ";domain=.jia.com;path=/;expires=" + exp.toGMTString();
};
var isManualURL = function (citySpell) {//判断用户是否手动输入的URL地址
    var url = window.location.href;
    if (url.indexOf(citySpell + ".jia.com") > -1) return true;
    return false;
};

var $subsite_guide = $(".city-guide");
$(".city-advice a,.city-guess a").click(function (e) {//设置cookie再跳转
    var url = $(this).attr("href"), jia_city_id, jia_city_name;
    if (url.indexOf("www.jia.com") < 0) {//分站时
        jia_city_id=url.substring(7, url.indexOf(".jia.com"));
        if($(this).text().indexOf("站")>0){
            jia_city_name=$(this).text().substring(0,$(this).text().length-1);
        }
        else{
            jia_city_name = $(this).text();
        }
    }else{//全国站时
        jia_city_id="other";
        jia_city_name="全国"
    }
    setCookie("jia_city_id", jia_city_id);
    setCookie("jia_city_name", jia_city_name)
})
$(".btn-close").click(function () {//关闭分站提示
    $subsite_guide.slideUp(1000);
})
$.getJSON("http://zhuangxiu.jia.com/new_api/city_ip_area.php?&callback=?", function (data) {
    $(".city-guess a").attr("href", "http://" + data.city_area + ".jia.com").text(data.city_name + "站");
    if (!isManualURL(data.city_area) && data.sub_attribute) {//如果是用户输入的分站与ip相符，或是分站状态为0则隐藏分站引导
        $subsite_guide.show();
    }
})
