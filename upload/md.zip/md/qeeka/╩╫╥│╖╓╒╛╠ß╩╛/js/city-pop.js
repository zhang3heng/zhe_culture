function getCookie(name) {
    var arr, reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg))
        return (arr[2]);
    else
        return null;
}
var fz_city_id = getCookie("jia_city_id");
document.write('<link href="http://ued.jia.com/css/common/city-pop.css" rel="stylesheet"><div class="overlay"></div><div class="city-box"><p class="city-guess">我们猜你可能想要进入：<em><a href="http://www.jia.com" tjjj="city.pop.1"> 全国站</a></em></p><p class="city-advice"><span>推荐城市站点：</span>         <a href="http://beijing.jia.com" title="北京" tjjj="city.pop.2">北京</a>         <a href="http://shanghai.jia.com" title="上海" tjjj="city.pop.3">上海</a>         <a href="http://hangzhou.jia.com" title="杭州" tjjj="city.pop.4">杭州</a>         <a href="http://nanjing.jia.com" title="南京" tjjj="city.pop.5">南京</a>         <a href="http://suzhou.jia.com" title="苏州" tjjj="city.pop.6">苏州</a>     </p>     <p class="viewmore"><a href="http://www.jia.com/citylist"  tjjj="city.pop.more" title="查看更多">查看更多</a></p>     <a class="btn-close" href="javascript:void(0)" title="关闭"></a> </div>');
if (fz_city_id === null) {
    var $subsiteBox = $(".city-box");
    var setCookie = function (name, value) {//设置cookie
        var exp = new Date("December 31,2020");
        document.cookie = name + "=" + encodeURI(value) + ";domain=.jia.com;path=/;expires=" + exp.toGMTString();
    };
    var isManualURL = function (citySpell) {//判断用户是否手动输入的URL地址
        var url = window.location.href;
        if (url.indexOf(citySpell + ".jia.com") > -1) return true;
        return false;
    };
    var showSubsiteBox = function () {//显示分站引导
        $(".overlay").show();
        $subsiteBox.show()
    };
    var hideSubsiteBox = function () {//隐藏分站引导
        $(".overlay").hide();
        $subsiteBox.hide();
    };
    var setOtherCookie = function (name, value) {
        var date = new Date();
        date.setTime(date.getTime() + 3 * 24 * 3600 * 1000);
        var exps = date.toGMTString();
        document.cookie = name + "=" + encodeURI(value) + ";domain=.jia.com;path=/;expires=" + exps;
    }
    $(".city-advice a,.city-guess a").click(function (e) {
        var url = $(this).attr("href"), jia_city_name;
        if ($(this).text().indexOf("站") > 0) {
            jia_city_name = $(this).text().substring(0, $(this).text().length - 1);
        }
        else {
            jia_city_name = $(this).text();
        }
        setCookie("jia_city_id", url.substring(7, url.indexOf(".jia.com")));
        setCookie("jia_city_name", jia_city_name);
    })
    $(".btn-close").click(function () {
        $(".overlay").hide();
        $(this).parents(".city-box").hide();
        setOtherCookie("jia_city_id", "other");
        setOtherCookie("jia_city_name", "全国");
    })
    $.getJSON("http://zhuangxiu.jia.com/new_api/city_ip_area.php?&callback=?", function (data) {
        $(".city-guess a").attr("href", "http://" + data.city_area + ".jia.com").text(data.city_name + "站");
        if (!isManualURL(data.city_area) && data.sub_attribute) {//如果是用户输入的分站与ip相符，或是分站不存在则隐藏分站引导
            showSubsiteBox();
        } else {
            hideSubsiteBox();
        }
    })
}
