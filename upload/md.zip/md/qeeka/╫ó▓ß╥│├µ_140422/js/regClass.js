/*
 $btn 提交按钮
 $list 验证列表
 tipfn 提示方法
 successfn 成功执行
 isfb  .focus.blur

 */

function regClass($btn, $form, tipfn, successfn, isfb) {
    this.self = this;
    this.btn = $btn;
    this.form = $form;
    this.list = $form.find('*[reg]');
    this.tipfn = tipfn;
    this.successfn = successfn;
    this.isfb = isfb || true;
    this.regs = {
        authcode: /^[a-z]{4}$/,
        mobile: /^1[3|4|5|8][0-9]\d{8}$/,
        tel: /^(\d{3,4}\d{7,8})$/,
        emailstandard: /^[a-zA-Z0-9-._]+@[a-zA-Z0-9-._]+.[a-z]{2,4}$/,
        email: /@/,
        hostname: /^[a-zA-Z0-9-._]+.[a-z]{2,3}$/,
        hostnamefirst: /^[a-zA-Z0-9-._]+$/,
        empty: /^\S+$/,
        nexdrule: /^[d]\d{1,}$/,
        nexdruleextend: /^[d]\d{1,}-\d{1,}$/,
        number: /^\d{1,}$/,
        birth: /^[1-2][0-9]\d{2}-(([0][1-9])|([1][0-2]))-([0-2][0-9])|([3][0-1])$/,
        year: /^[1-2][0-9]\d{2}$/,
        month: /^([0][1-9])|([1][0-2])$/,
        day: /^([0-2][0-9])|([3][0-1])$/,
        cnandnotnull: /^[\u4E00-\u9FA5\x00-\xff]+$/g,
        enandnotnull: /^[a-zA-Z]+$/,
        zipcode: /^[1-9][0-9]{5}$/,
        commit: "commit",
        username: /^[a-zA-Z0-9\u4E00-\u9FA5_-、]{4,20}$/,
        l6: function ($item) {
            if ($item.val().length > 5)
                return true;
            else
                return false;
        },
        vercode: /^\d{6}$/
    };
    //执行
    this.init();
}
regClass.prototype = {
    init: function () {
        var self = this.self;
        self.btn.click(function () {
            if (self.btn.hasClass('no_submitBtn')) {
                return false;
            }
            if (self.checkall(false) && self.form.find('span.error').length < 1 && activeCheck.checkAccess()) {
                self.successfn();
                //check success
                self.btn.addClass('no_submitBtn');
            } else {
                return false;
            }
        });
        self.FB();
    },
    checkall: function (checkactive) {
        var self = this.self, regs = self.regs;
        var $list = self.list, len = $list.length, i = 0, _temp = "", errlen = 0;
        for (; i < len; i++) {
            if (!self.checkone($list.eq(i)), checkactive)
                errlen++;
        }
        if (errlen > 0)
            return false;
        else
            return true;
    },
    checkone: function ($item, checkactive, onSuccess) {
        var self = this.self, _val = $.trim($item.val()) || '', canempty = $item.attr('canempty') || 'false';
        if ($.trim(_val) == '') {
            if (canempty == "false") {
                self.tipfn.empty($item);
                return false;
            } else {
                $item.parent().find('span.error').remove();
                activeCheck.inAjaxCheck['email'] = true;
                return true;
            }
        }
        var reg = self.regs[$item.attr('reg') || 'empty'], check = false, num = false, china = false, showok = $item.attr('checkactive') || 'none', commit = $item.attr('commit') || 'noele';

        if (typeof reg == 'function') {
            check = reg.call(this, $item);
        } else if (commit == '#password') {
            check = _val == $(commit).val();
        } else {
            if (commit == 'num') {
                var _num = $.trim(_val).replace(/[0-9]/g, "");
                var _china = $.trim(_val).replace(/[\u4e00-\u9fa5]/g, "aa");
                if (!_num) {
                    check = false;
                    num = true;
                } else {
                    if (reg.test(_china)) {
                        check = true;
                    } else {
                        check = false;
                        if (reg.test(_val)) {
                            china = true;
                        }
                    }
                }
            } else {
                if ($item.attr('reg') == 'mobile') {
                    _val = _val.replace(/[^\d]/g, '');
                }
                check = reg.test(_val);
            }
        }
        if (check) {
            if (showok != 'none') {
                //self.tipfn.hide($item);
                if (checkactive) {
                    activeCheck.doCheck($item, showok, onSuccess);
                }
            } else {
                self.tipfn.ok($item);
            }
            return true;
        } else {
            if (!num) {
                if (china) {

                    self.tipfn.china($item);
                } else {
                    self.tipfn.wrong($item);
                }
            } else {
                self.tipfn.num($item);
            }
            return false;
        }
    },
    FB: function () {
        var self = this.self;
        self.list.focus(function () {
            if ($.trim($(this).val()) != "") {
                return;
            }
            self.tipfn.show($(this));
        }).bind('blur', function () {
                self.checkone($(this), true);
            });
        /*.blur(function(){
         self.tipfn.hide($(this));
         });*/
    }
};

var _tipShow = {
    show: function ($this) {
        showError($this, 'warn', 'ver', 's');
    },
    hide: function ($this) {
        showError($this, null, null, 'h');
    },
    wrong: function ($this) {
        showError($this, 'error', 'errorMess', 's');
    },
    ok: function ($this) {
        showError($this, 'ok', '', 'ok');
    },
    empty: function ($this) {
        showError($this, 'error', 'emptyMess', 's');
    },
    commit: function ($this) {
        showError($this, 'error', 'commitMess', 's');
    },
    num: function ($this) {
        showError($this, 'error', 'numMess', 's')
    },
    china: function ($this) {
        showError($this, 'error', 'chinaMess', 's')
    }
};

//比对
function showError($obj, classname, textAttr, state, istext, deftext) {
    var $span = $obj.parent().find('span');
    var _wadd = $obj.attr('wrongaddclass') || '';

    if (_wadd != '') {
        if (classname == "error") {
            $obj.addClass(_wadd);
        }
        else {
            if (classname != "warn") {
                $obj.removeClass(_wadd);
            }
        }
    }

    if (state == 'h') {
        $span.hide();
        return false;
    }
    var text = '';
    try {
        text = $obj.attr(textAttr);
    } catch (e) {
    }
    if (text == 'none' || text == undefined) {
        if (state == 'ok') {
            text = '';
        }
    }
    if (istext) {
        text = deftext;
    }
    if ($span.length > 0) {
        $span.removeClass().addClass(classname).html(text);
        $span.show();
    } else {
        $('<strong style="padding-left:7px;display:inline-block;font-weight:normal;"><span style="margin-left:0;" class="' + classname + '">' + text + '</span></strong>').appendTo($obj.parent());
    }
}


var activeCheck = {
    /*@type 请求类型，根据不同类型向不同的url请求验证*/
    doCheck: function ($this, type, onSuccess) {
        if (type == "username") {
            activeCheckAjax($this, '/cas/register/checkName', {name: $.trim($this.val()), type: 1, loginUrl: $('#loginHref').attr('href')}, 'username');
        }
        if (type == "mobile") {
            activeCheckAjax($this, '/cas/register/checkMobile', {mobile: $this.val().replace(/[^\d]/g, ''), type: 1, loginUrl: $('#loginHref').attr('href')}, 'mobile');
        }
        if (type == "email") {
            activeCheckAjax($this, '/cas/register/checkEmail', {email: $this.val(), type: 1, loginUrl: $('#loginHref').attr('href')}, 'email');
        }
        if (type == "authcode") {
            activeCheckAjax($this, 'http://localhost:3000/checkAuthcode', {authcode: $this.val(), type: 1, loginUrl: $('#loginHref').attr('href')}, 'authcode', '', onSuccess)
        }

    },
    //email:function($this){
    //	activeCheckAjax($this,location.href,{},'email');
    //},
    inAjaxCheck: {},
    checkAccess: function () {
        for (var _item in activeCheck.inAjaxCheck) {
            if (activeCheck.inAjaxCheck[_item] != true) {
                return false;
            }
        }
        return true;
    }
};


function activeCheckAjax($this, url, data, type, tips, onSuccess) {
    //if($this.attr('lastval')==$this.val()){ return false; }
    //$this.attr('lastval',$this.val());
    activeCheck.inAjaxCheck[type] = false;
    $.ajax({
        url: url,
        data: data,
        type: "POST",
        jsonp: "callback",
        cache: false,
        dataType: "jsonp",
        success: function (e) {
            //e = 'true';
            if (e == "ok") {
                showError($this, 'ok', '', 'ok');
                activeCheck.inAjaxCheck[type] = true;
                if ($.type(onSuccess) === "function") onSuccess();//回调
            } else {
                showError($this, 'error', 'checkactivetip', 's', true, e);
            }
        },
        error: function () {
            //showError($this,'error','checkactivetip','s');
        }
    });
}

//页面通用
$(function () {
    var $regBtn = $('#regBtn');
    var $iagree = $('#iagree');
    $iagree.click(function () {
        if (!this.checked) {
            $regBtn.addClass('no_submitBtn');
        } else {
            $regBtn.removeClass('no_submitBtn');
        }
    });
});

function researchEmail() {
    //邮箱
    var $email = $('#email');
    var $email_list = $('#email_list');
    var $email_cont = $('#email_cont');
    var email_ary = ['sina.com', '163.com', 'qq.com', 'sina.cn', 'vip.sina.com', 'hotmail.com', 'souhu.com', '126.com', '189.cn', 'wo.com.cn'];
    var email_len = email_ary.length;
    var email_cur = 0;
    var reg_email = /^([a-zA-Z0-9_\.-])+@([a-zA-Z0-9_-])+((\.[a-zA-Z0-9_-]{2,}){1,2})$/;
    var reg_telx = /[1]\d{10}/;
    var $reg_tel = $('#reg_tel');
    //邮箱
    $email.focusin(function () {
        //$(this).addClass('focus_email');
        //$email_cont.html('');
    }).keyup(function (event) {
            var myEvent = event || window.event;
            var k = myEvent.keyCode;
            if (k != 38 && k != 40 && k != 13 && k != 9) {
                var $this = $(this);
                var $val = $this.val();
                var _temp = [];
                var _end = $val.substring($val.indexOf('@') + 1, $val.length);
                var _start = $val.substring(0, $val.indexOf('@'));
                //     _temp.push("<li>"+$val+"</li>");
                if ($val.indexOf('@') != -1 && _end.length != 0) {
                    for (var i = 0; i < email_len; i++) {
                        if (email_ary[i].indexOf(_end) != -1 && _start + "@" + email_ary[i] != $this.val())
                            _temp.push("<li>" + _start + "@" + email_ary[i] + "</li>");
                    }
                } else {
                    for (var i = 0; i < email_len; i++) {
                        _temp.push("<li>" + $val.replace(/[@]/g, '') + "@" + email_ary[i] + "</li>");
                    }
                }
                $email_cont.html(_temp.join(''));
                $email_list.css({display: 'block'});
                var $item = $email_cont.find('li');
                $item.eq(0).addClass('hover');
                email_cur = 0;
                $item.mouseover(function () {
                    if ($(this).hasClass('keyup')) {
                        $(this).removeClass('keyup');
                    }
                    $(this).addClass('hover').siblings('li').removeClass('hover');
                    email_cur = $(this).index();
                }).click(function () {
                        if ($email_list.is(':visible')) {
                            $email.val($(this).html());
                            $.initVerText('邮箱', 2, 'email', reg_email);
                            $email_list.hide();
                        }
                    });
            }
        }).focusout(function () {
            var $reg_v = $.trim($reg_tel.val());
            $(this).removeClass('focus_email');
            if ($.trim($(this).val()).length != 0) {
                if ($email_cont.find('li.keyup').length != 0) {
                    $email.val($email_cont.find('li.keyup').html());
                } else {
                    if ($email_cont.find('li.hover').length != 0)
                        $email.val($email_cont.find('li.hover').html());
                }
            }
            $email_list.hide();
        });

    $email_cont.mouseout(function () {
        $(this).find('li:first').addClass('hover').siblings('li').removeClass('hover');
        email_cur = 0;
    });

    $(document).bind('keyup',function (event) {
        var myEvent = event || window.event;
        var k = myEvent.keyCode;
        var _len = $email_cont.find('li').length;
        if ($email_list.is(':visible')) {
            if (k == 38) {
                if (email_cur > 0) email_cur--;
                else email_cur = _len - 1;
                email_roll(email_cur);
            }
            else if (k == 40) {
                if (email_cur < _len - 1) email_cur++;
                else email_cur = 0;
                email_roll(email_cur);

            }
            else if (k == 13) {
                if ($email_cont.find('li.keyup').length != 0)
                    $email.val($email_cont.find('li.keyup').html());
                $email_list.hide();
            }
        }
    }).bind('click', function () {
            $email_list.hide();
        });

    function email_roll(n) {
        $email_cont.find('li').eq(n).addClass('keyup').siblings('li').removeClass('hover keyup');
    }

    //end 邮箱
}