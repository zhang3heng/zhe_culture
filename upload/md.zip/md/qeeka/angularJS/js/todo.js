function TodoCtrl($scope) {
    $scope.todos = [
        {text: "单选一", done: false},
        {text: "单选二", done: true}
    ]
    $scope.addTodo=function(){
        if(!$scope.todoText.length) return;//值为空是返回
        $scope.todos.push({text:$scope.todoText,done:false})
        $scope.todoText="";
    }
    $scope.remaining=function(){
        var counter=0;
        angular.forEach($scope.todos,function(todo){
            counter+=todo.done?1:0;
        })
        return counter;
    }
}