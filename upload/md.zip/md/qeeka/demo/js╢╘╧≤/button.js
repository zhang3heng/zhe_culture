(function($){
    "use strict"
    var Button=function(){

    }
})(jQuery)