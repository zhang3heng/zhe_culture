$(function(){ 
  var sliderSwiper=$('.swiper-container').swiper({
    loop:true,
	autoplay:3000,
	pagination:'.indicator',
	calculateHeight: true,
	paginationClickable:true
  });
}); 
