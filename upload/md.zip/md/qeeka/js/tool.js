//设置cookie
var setCookie = function (name, value) {
    var exp = new Date("December 31,2020");
    document.cookie = name + "=" + encodeURI(value) + ";domain=.jia.com;path=/;expires=" + exp.toGMTString();
};
//获取cookie
var getCookie = function (name) {
    var arr,
        reg = new RegExp("(^| )" + name + "=([^;]*)(;|$)");
    if (arr = document.cookie.match(reg)) {
        return (arr[2]);
    }
    else {
        return null;
    }
}