(function ($) {
    $.fn.easyMarquee = function (options) {
        var _this = this;
        var opts = $.extend({}, $.fn.easyMarquee.defaults, options);
        var $container = $(this),
            $wrapper = $container.find(".marquee-wrapper").size > 0 ? $container.find(".marquee-wrapper") : $container.children(),
            $e_sub = $wrapper.find("li"),
            subWidth = $e_sub.width(),
            subHeight = $e_sub.height(),
            active_index = 0,
            $sub_visible;

        //用户自定义要显示的数据行数
        var customShow = function () {
            var dSize = opts.showLength,
                eSize = $e_sub.size();
            var rollSize = eSize < dSize ? eSize : dSize;
            if (opts.rollY) {
                $container.height(subHeight * rollSize);
            } else {
                $container.width(subWidth * rollSize);
            }
        }

        /*
         * 得到对用户可见的子元素
         * */
        var getVisible = function () {
            var $sub_visible_wrapper = $("<div></div>"),
                $sub_visible_size;
            if (opts.rollY) $sub_visible_size = Math.ceil($container.height() / subHeight);
            else $sub_visible_size = Math.ceil($container.width() / subWidth);
            for (var i = 0; i < $sub_visible_size; i++) {
                $sub_visible_wrapper.append($e_sub.eq(i).clone());
            }
            return  $sub_visible_wrapper.find("li");
        }
        var rolling = function () {
            if (opts.rollY && !opts.isDelayRoll) {//垂直方向上的无缝滚动
                var d = $container.scrollTop();
                if (d == $e_sub.size() * subHeight) {
                    d = -opts.step;
                }
                d = d + opts.step;
                $container.scrollTop(d);
            }
            else if (opts.rollY && opts.isDelayRoll) {//垂直方向上的延迟滚动
                if (active_index == $e_sub.size()) {
                    $wrapper.css("top", 0);
                    active_index = 0;
                }
                active_index++;
                $wrapper.animate({
                    top: -active_index * subHeight
                }, opts.aniTime);
            } else if (!opts.rollY && opts.isDelayRoll) {//水平方向的延迟滚动
                if (active_index == $e_sub.size()) {
                    $wrapper.css("left", 0);
                    active_index = 0;
                }
                active_index++;
                $wrapper.animate({
                    left: -active_index * subWidth
                }, opts.aniTime);
            } else if (!opts.rollY && !opts.isDelayRoll) {//水平方向上的无缝滚动
                if ($container.scrollLeft() == ($e_sub.size() * subWidth)) {
                    $container.scrollLeft(0);
                } else {
                    $container.scrollLeft($container.scrollLeft() + parseInt(opts.step));
                }
            }
        }
        var bindEvent = function () {
            if ($.on) {//对低版本的jquery的支持
                $wrapper.on("mouseover", function () {//鼠标移到marquee上时，清除定时器，停止滚动
                    clearInterval(timer);
                })
                $wrapper.on("mouseout", function () {//鼠标移开时重设定时器)
                    timer = setInterval(rolling, opts.speed)
                })
            } else {
                $wrapper.bind("mouseover", function () {//鼠标移到marquee上时，清除定时器，停止滚动
                    clearInterval(timer);
                })
                $wrapper.bind("mouseout", function () {//鼠标移开时重设定时器)
                    timer = setInterval(rolling, opts.speed)
                })
            }
        }
        $sub_visible = getVisible();
        $wrapper.append($sub_visible);

        if (opts.rollY) {
            if (opts.customShowLength) customShow();
        } else {
            $wrapper.width(subWidth * $wrapper.find("li").size());
            if (opts.customShowLength) customShow();
        }

        var timer = setInterval(rolling, opts.speed)//设置定时器
        bindEvent();
    }

    $.fn.easyMarquee.defaults = {
        rollY: true,//滚动方向，为false则表示是水平方向的滚动
        speed: 30,//滚动的时间间隔
        customShowLength: false,
        showLength: 12,//显示的要滚动的数据行数
        isDelayRoll: false,//是否延迟滚动
        aniTime: 500,//延迟滚动时的动画时间
        step: 1//一次滚动的距离，单位是px;
    }
})(jQuery);