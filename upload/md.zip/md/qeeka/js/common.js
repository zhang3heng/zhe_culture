/**
 * Created by freeman on 14-1-14.
 */

$(function () {
    $("body").hoverTab();
});
/*鼠标hover时的切换效果*/
(function ($) {
    $.fn.hoverTab = function (options) {
        var opts = $.extend({}, $.fn.hoverTab.defaults, options)
        $(".tab-nav li").bind("mouseover", function () {
            var $this = $(this), $tabContent = $this.parents(".tab-nav").siblings(".tab-content");
            if ($this.hasClass("active")) return;
            $this.addClass("active").siblings(".active").removeClass("active");
            $tabContent.find(".tab-panel").removeClass("active").eq($this.index()).addClass("active");
        })
    }
    $.fn.hoverTab.defaults = {};
})(jQuery);






