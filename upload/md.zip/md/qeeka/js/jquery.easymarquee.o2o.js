(function ($) {
    var Marquee = function (element, options) {
        var _this = this;
        this.$container = $(element);
        this.opts = $.extend({}, $.fn.easyMarquee.defaults, options);
        this.$wrapper = this.$container.find(".marquee-wrapper").size > 0 ? this.$container.find(".marquee-wrapper") : this.$container.children();
        this.$e_sub = this.$wrapper.find("li");
        this.subWidth = this.$e_sub.width();
        this.subHeight = this.$e_sub.height();
        this.active_index = 0;
        this.$sub_visible = null;
        this.$sub_visible = this.visibleSub();
        this.$wrapper.append(this.$sub_visible);
        var customShow = function () {
            var dSize = _this.opts.showLength,
                eSize = _this.$e_sub.size();
            var rollSize = eSize < dSize ? eSize : dSize;//最大滚动元素应该小于或等于子元素
            if (_this.opts.rollY) {
                _this.$container.height(this.subHeight * rollSize);
            } else {
                _this.$container.width(this.subWidth * rollSize);
            }
        }

        var bindEvent = function () {
            if ($.on) {//对低版本的jquery的支持
                _this.$wrapper.on("mouseover", function () {//鼠标移到marquee上时，清除定时器，停止滚动
                    window.clearInterval(timer);
                })
                _this.$wrapper.on("mouseout", function () {//鼠标移开时重设定时器)
                    timer = window.setInterval(function () {
                        _this.roll();
                    }, _this.opts.speed);//设置定时器
                })
            } else {
                _this.$wrapper.bind("mouseover", function () {//鼠标移到marquee上时，清除定时器，停止滚动
                    window.clearInterval(timer);
                })
                _this.$wrapper.bind("mouseout", function () {//鼠标移开时重设定时器)
                    timer = window.setInterval(function () {
                        _this.roll();
                    }, _this.opts.speed);//设置定时器
                })
            }
        }
        /*用户指定要显示的行数*/
        if (this.opts.rollY) {
            if (this.opts.customShowLength) customShow();
        } else {
            this.$wrapper.width(this.subWidth * this.$wrapper.find("li").size());
            if (this.opts.customShowLength) customShow();
        }
        var timer = window.setInterval(function () {
            _this.roll();
        }, _this.opts.speed);//设置定时器
        bindEvent();
    }
    //滚动的主要代码
    Marquee.prototype.roll = function () {
        if (this.opts.rollY && !this.opts.isDelayRoll) {//垂直方向上的无缝滚动
            var d = this.$container.scrollTop();
            if (d == this.$e_sub.size() * this.subHeight) {
                d = -this.opts.step;
            }
            d = d + this.opts.step;
            this.$container.scrollTop(d);
        }
        else if (this.opts.rollY && this.opts.isDelayRoll) {//垂直方向上的延迟滚动
            if (this.active_index == this.$e_sub.size()) {
                this.$wrapper.css("top", 0);
                this.active_index = 0;
            }
            this.active_index++;
            this.$wrapper.animate({
                top: -this.active_index * this.subHeight
            }, this.opts.aniTime);
        } else if (!this.opts.rollY && this.opts.isDelayRoll) {//水平方向的延迟滚动
            if (this.active_index == this.$e_sub.size()) {
                this.$wrapper.css("left", 0);
                this.active_index = 0;
            }
            this.active_index++;
            this.$wrapper.animate({
                left: -this.active_index * this.subWidth
            }, this.opts.aniTime);
        } else if (!this.opts.rollY && !this.opts.isDelayRoll) {//水平方向上的无缝滚动
            if (this.$container.scrollLeft() == (this.$e_sub.size() * this.subWidth)) {
                this.$container.scrollLeft(0);
            } else {
                this.$container.scrollLeft(this.$container.scrollLeft() + parseInt(this.opts.step));
            }
        }
    }
    /*获取初始时所有可见的子元素*/
    Marquee.prototype.visibleSub = function () {
        var $sub_visible_wrapper = $("<div></div>"),
            $sub_visible_size;
        if (this.opts.rollY) $sub_visible_size = Math.ceil(this.$container.height() / this.subHeight);
        else $sub_visible_size = Math.ceil(this.$container.width() / this.subWidth);
        for (var i = 0; i < $sub_visible_size; i++) {
            $sub_visible_wrapper.append(this.$e_sub.eq(i).clone());
        }
        return  $sub_visible_wrapper.find("li");
    }
    $.fn.easyMarquee = function (options) {
        return this.each(function () {
            new Marquee(this, options);
        })
    }
    $.fn.easyMarquee.constructor = Marquee;
    $.fn.easyMarquee.defaults = {
        rollY: true,//滚动方向，为false则表示是水平方向的滚动
        speed: 30,//滚动的时间间隔
        customShowLength: false,
        showLength: 12,//显示的要滚动的数据行数
        isDelayRoll: false,//是否延迟滚动
        aniTime: 500,//延迟滚动时的动画时间
        step: 1//一次滚动的距离，单位是px;
    }
})(jQuery);