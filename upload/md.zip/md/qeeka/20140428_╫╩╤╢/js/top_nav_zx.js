var location_url = document.location.href;
var city_name = '\u65e0\u9521';
var skip_set_city = 0;
var suffix = '';
var host_url = '';
var site_domain = '';
host_url = window.location.host;
host_url = host_url.toLowerCase();
site_domain = host_url;

function getLoginUser(user) {
    if (user == '') {
        ini_top_nav_html('');
    } else {
        ini_top_nav_html(user.name);
    }
}

function URLEncode(clearString) {
    var output = '';
    var x = 0;
    clearString = clearString.toString();
    var regex = /(^[a-zA-Z0-9-_.]*)/;
    while (x < clearString.length) {
        var match = regex.exec(clearString.substr(x));
        if (match != null && match.length > 1 && match[1] != '') {
            output += match[1];
            x += match[1].length;
        } else {
            if (clearString.substr(x, 1) == ' ') {
                clearString[x] == ' '
                output += '+';
            }
            else {
                var charCode = clearString.charCodeAt(x);
                var hexVal = charCode.toString(16);
                output += '%' + ( hexVal.length < 2 ? '0' : '' ) + hexVal.toUpperCase();
            }
            x++;
        }
    }
    return output;
}
function ini_top_nav_html(login_user) {
    var city_id = '';
    city_id = jia_header_get_cookie('jia_city_id');
    if (city_id == 'shanghai' || city_id == 'other') {
        var fenzhan = '';
    } else {
        var fenzhan = city_id + '/';
    }
    var div_city_id = city_id;
    var app_id = '201';
    if (site_domain == 'zhuangxiu.jia.com') {
        app_id = '200';
    }
    var returl = URLEncode(location_url);

    var top_nav_html = '';

    if (!login_user) {
        top_nav_html = '<li>';
        top_nav_html += '<a href="https://passport.jia.com/cas/login?service=' + returl + '&app_id=' + app_id + '" id="login">登录</a> ';
        top_nav_html += '<a href="https://passport.jia.com/cas/register?app_id=' + app_id + '&service=' + returl + '" id="register">注册</a>';
        top_nav_html += '<span class="separator">|</span>';
        top_nav_html += '</li>';
    } else {
        top_nav_html += '<li class="user-info">欢迎您！';
        top_nav_html += '<div class="user-dropdown">';
        top_nav_html += '<a class="user-tip" href="javascript:void(0)">' + login_user + '<i class="caret"></i></a>';
        top_nav_html += '<ul class="dropdown-list">';
        top_nav_html += '<li><a href="http://i.jia.com/">我的齐家</a></li>';
        top_nav_html += '<li><a href="http://i.jia.com/order/order_list.htm">我的订单</a></li>';
        top_nav_html += '<li><a href="http://bbs.jia.com/' + fenzhan + '" target="_blank">我的论坛</a></li>';
        top_nav_html += '<li><a href="https://passport.jia.com/cas/logout?app_id=' + app_id + '&service=' + returl + '">安全退出</a></li>';
        top_nav_html += '<input id="url" type="hidden" value="" name="url">';
        top_nav_html += '</ul>';
        top_nav_html += '</div>';
        top_nav_html += '<span class="separator">|</span>';
        top_nav_html += '</li>';
    }


    top_nav_html += '<li class="mini_cart">';
    top_nav_html += '<a class="menu_hd" href="http://mall.jia.com/order/cart/get_cart"><s></s>购物车<b></b><span style="color:#A8000D" class="red">(0)</span></a>';
    top_nav_html += '<div class="menu_bd hide"><h2 class="cart_hd">最近加入的商品：</h2><span class="show_cart_msg"></span><ul class="cart_bd"></ul>';
    top_nav_html += '<div class="cart_ft">';
    top_nav_html += '<p class="cart_info">购物车里还有<em></em>个商品</p>';
    top_nav_html += '<p class="cart_operate"><a class="cart_lookup" href="http://mall.jia.com/order/cart/get_cart"><span  style="color:#fff">查看我的购物车</span></a></p>';
    top_nav_html += '</div></div>';
    top_nav_html += '</li>';

    top_nav_html += '<li class="city">';
    top_nav_html += '<span class="separator">|</span>';
    top_nav_html += '' + city_name + '<a href="http://www.jia.com/citylist/">[更换城市]</a>';
    top_nav_html += '</li>';

    jQuery("#user-info").html(top_nav_html);

    jQuery(".myorder,.mini_cart").hover(function () {
        jQuery(this).find(".menu_bd").removeClass("hide").addClass("show");
        load_cart_data();
    }, function () {
        jQuery(this).find(".menu_hd").removeClass("hover");
        jQuery(this).find(".menu_bd").removeClass("show").addClass("hide");
    });

    jQuery(".mini_cart .cart_bd li").hover(function () {
        jQuery(this).toggleClass("item-highlight");
    });
    load_cart_data();

}

function del_cart_item(item_id, obj) {
    var $this = jQuery(obj);
    jQuery.ajax({
        url: 'http://mall.jia.com/order/cart/top_nav_delete_cart?item_id=' + item_id + '&callback=?',
        type: 'GET',
        async: false,
        dataType: 'jsonp',
        jsonp: 'callback',
        success: function (data) {
            jQuery(".menu_hd .red").text("(" + data['count'] + ")");
            var parentNode = $this.parent().parent().parent();
            parentNode.remove();
            jQuery(".show_cart_msg").html("");
            jQuery(".cart_bd li").eq(4).show();
            var count = (data['count'] - 5 > 0) ? (data['count'] - 5) : 0;
            jQuery(".cart_info em").text(count);
            load_cart_data();
        }
    });
}


function ini_cart_data(da) {
    var data = da.list;
    var item_count = da.item_count;
    if (item_count.shop_msg == 0) {
        jQuery(".menu_hd .red").text("");
        jQuery(".show_cart_msg").html("&nbsp;&nbsp;您的购物车暂时为空，请赶快购物吧！");
        jQuery(".menu_bd ul").html("");
        jQuery(".cart_info em").text('0');
        jQuery(".mini_cart s").removeClass('has');
        jQuery(".menu_hd .red").text("(0)");
    } else {
        var str = '';
        var p_show = 0;
        for (var i = 0; i < data.length; i++) {
            str += '<li class="list' + data[i].itemId + '" ';
            if (i > 4) {
                str += 'style="display: none;"';
            }
            str += '><div class="mc_cart_img"><a href="http://mall.jia.com/item/' + data[i].itemId + '" target="_blank">';
            str += '<img src="http://imgmall.tg.com.cn/' + data[i].imagePath + '" width="40" height="40" ></a></div>';
            str += '<div class="mc_goods_info"><a class="mc_goods_name" href="http://mall.jia.com/item/' + data[i].itemId + '" target="_blank">' + data[i].name + ' *' + data[i].product_count + '</a> </div>';
            str += '<div class="mc_right"> <p class="mc_cart_price">';
            if (data[i].comments || data[i].comments == 'undefined') {
                str += '<span> 颜色:' + data[i].comments + '</span>';
            }
            str += '<span>' + (data[i].price * data[i].product_count).toFixed(2) + '</span> 元</p>     <p class="mc_cart_del"><a href="javascript:void(0)" class="del_item_by_cart" onclick="del_cart_item(' + data[i].itemId + ',this)">删除</a></p>   </div></li>';
            if (i < 5) {
                p_show = parseInt(p_show) + parseInt(data[i].product_count);
            }
        }
        jQuery(".show_cart_msg").html("");
        jQuery(".menu_bd ul").html("");
        jQuery(".menu_hd .red").text("(" + item_count['product_show_count'] + ')');
        jQuery(".cart_bd ").append(str);
        jQuery(".mini_cart s").addClass('has');
        if (parseFloat(da['item_count']['product_show_key']) < 5) {
            jQuery(".cart_info em").text(0);
            jQuery(".cart_info").hide();
        } else {
            jQuery(".cart_info em").text((parseInt(item_count['product_show_count']) - p_show));
        }
    }
}


function load_cart_data() {
    jQuery.ajax({
        type: "get",
        url: "http://mall.jia.com/order/cart/top_nav_js?json=true&callback=?",
        dataType: "jsonp",
        jsonp: 'callback',
        cache: false,
        timeout: 10000,
        error: function (error) {
        },
        success: function (da) {
            jQuery(".cart_bd ").html("");
            ini_cart_data(da);
        }
    });
}

function jia_header_get_cookie(c_name) {
    if (document.cookie.length > 0) {
        c_start = document.cookie.indexOf(c_name + "=");
        if (c_start != -1) {
            c_start = c_start + c_name.length + 1;
            c_end = document.cookie.indexOf(";", c_start);
            if (c_end == -1) c_end = document.cookie.length;
            return unescape(document.cookie.substring(c_start, c_end));
        }
    }
    return "";
}
jQuery("head").append("<script src='https://passport.jia.com/cas/login/user'?r=" + Math.random() + "\'></script>");